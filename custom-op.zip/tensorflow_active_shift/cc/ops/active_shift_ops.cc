/* Copyright 2016 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

// See docs in ../ops/nn_ops.cc.

#define EIGEN_USE_THREADS

#include <cfloat>
#include <vector>


#include "third_party/eigen3/unsupported/Eigen/CXX11/Tensor"
#include "tensorflow/core/framework/op.h"
#include "tensorflow/core/framework/op_kernel.h"
#include "tensorflow/core/framework/register_types.h"
#include "tensorflow/core/framework/tensor.h"
#include "tensorflow/core/framework/tensor_shape.h"
#include "tensorflow/core/framework/shape_inference.h"
#include "tensorflow/core/util/tensor_format.h"
//#include "tensorflow/core/kernels/bounds_check.h"
#include "tensorflow/core/framework/bounds_check.h"

#include "tensorflow/core/platform/stream_executor.h"
#include "../../cc/kernels/active_shift2d.h"

namespace tensorflow {
using shape_inference::DimensionHandle;
using shape_inference::InferenceContext;
using shape_inference::ShapeHandle;


namespace {
template <typename T>
perftools::gputools::DeviceMemory<T> AsDeviceMemory(const T* cuda_memory) {
  perftools::gputools::DeviceMemoryBase wrapped(const_cast<T*>(cuda_memory));
  perftools::gputools::DeviceMemory<T> typed(wrapped);
  return typed;
}
} //namespace

namespace functor {
Status compute_output_shapes(const int64 input_size, const int64 stride, const int64 padding, int64* output_size){
    if (stride <= 0) {
	return errors::InvalidArgument("Stride must be > 0, but got ", stride);
    }

    *output_size = (input_size + 2 * padding - 1) / stride + 1;

    if(*output_size < 0) {
	return errors::InvalidArgument(
		"Computed output size would be negative: ", *output_size, 
                " [input_size: ", input_size, 
                ", stride: ", stride, 
                ", padding: ", padding, "]");
    }

    return Status::OK();
}
}

REGISTER_OP("ActiveShift2DOp")
.Input("x: T")		// [ batch, in_channels, in_rows, in_cols]
.Input("shift: T")	// [ 2, in_channels]
.Output("output: T")
.Attr("T: {float, double}")
.Attr("strides: list(int)")
.Attr("paddings: list(int)")
.Attr("normalize: bool = false")
.Attr("data_format: { 'NHWC', 'NCHW' } = 'NCHW' ")
.SetShapeFn([](InferenceContext* c) {
    ShapeHandle input_shape;
    TF_RETURN_IF_ERROR(c->WithRank(c->input(0), 4, &input_shape));
    ShapeHandle shift_shape;
    TF_RETURN_IF_ERROR(c->WithRank(c->input(1), 2, &shift_shape));

    string data_format;
	TensorFormat data_format_;
	TF_RETURN_IF_ERROR(c->GetAttr("data_format", &data_format));
	FormatFromString(data_format, &data_format_);
	CHECK(data_format_ == FORMAT_NCHW) << "ACU implementation only supports NCHW tensor format for now.";


    std::vector<int32> strides;
    TF_RETURN_IF_ERROR(c->GetAttr("strides", &strides));
    if (strides.size() != 4) {
        return errors::InvalidArgument(
                   "ActiveShift2D requires the stride attribute to contain 4 values, but "
                   "got: ", strides.size());
    }
    const int32 stride_h = GetTensorDim(strides, data_format_, 'H');
    const int32 stride_w = GetTensorDim(strides, data_format_, 'W');


    std::vector<int32> paddings;
	TF_RETURN_IF_ERROR(c->GetAttr("paddings", &paddings));
	if (paddings.size() != 4) {
		return errors::InvalidArgument(
				   "ActiveShift2D requires the padding attribute to contain 4 values, but "
				   "got: ", paddings.size());
	}
	const int32 pad_h = GetTensorDim(paddings, data_format_, 'H');
	const int32 pad_w = GetTensorDim(paddings, data_format_, 'W');

    DimensionHandle batch_size_dim = c->Dim(input_shape, 0);
    DimensionHandle in_channels_dim = c->Dim(input_shape, 1);
    DimensionHandle in_rows_dim = c->Dim(input_shape, 2);
    DimensionHandle in_cols_dim = c->Dim(input_shape, 3);

    DimensionHandle output_depth_dim = in_channels_dim;


    auto in_rows = c->Value(in_rows_dim);
    auto in_cols = c->Value(in_cols_dim);

    int64 output_rows, output_cols;
    functor::compute_output_shapes(in_rows, stride_h, pad_h, &output_rows);
    functor::compute_output_shapes(in_cols, stride_w, pad_w, &output_cols);

    ShapeHandle output_shape = c->MakeShape(
    {batch_size_dim, output_depth_dim, output_rows, output_cols});
    c->set_output(0, output_shape);
    return Status::OK();
})
.Doc(R"doc(
only support NCHW now
)doc");


REGISTER_OP("ActiveShift2DBackpropOp")
.Input("x: T")		// [ batch, in_channels, in_rows, in_cols]
.Input("shift: T")	// [ 2, in_channels]
.Input("out_grad: T")
.Output("x_grad: T")
.Output("shift_grad: T")
.Attr("T: {float, double}")
.Attr("strides: list(int)")
.Attr("paddings: list(int)")
.Attr("normalize: bool = false")
.Attr("data_format: { 'NHWC', 'NCHW' } = 'NCHW' ")
.SetShapeFn([](InferenceContext* c) {
    c->set_output(0, c->input(0));
    c->set_output(1, c->input(1));
    return Status::OK();    
})
.Doc(R"doc(
only support NCHW now
)doc");

} //namespace tensorflow
