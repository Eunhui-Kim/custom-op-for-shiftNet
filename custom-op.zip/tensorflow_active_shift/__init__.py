# from active_conv_op import active_conv_op
# from active_conv_op import active_conv_grad_op

# active_conv = active_conv_op
""" Tensorflow GPU op """

from __future__ import absolute_import

from tensorflow_active_shift.python.ops import active_shift2d_ops
